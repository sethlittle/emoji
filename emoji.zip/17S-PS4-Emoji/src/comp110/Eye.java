package comp110;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
//import javafx.scene.shape.Path;
//import javafx.scene.shape.Rectangle;
//import javafx.scene.shape.MoveTo;
//import javafx.scene.shape.LineTo;

public class Eye {

	private double _x;
	private double _y;
	private double _radius;
	private Color _irisColor;

	public Eye(Color color) {
		this.setIrisColor(color);
		this.getIrisColor();
		_x = -3.0;
		_y = -3.0;
	}

	public void setIrisColor(Color color) {
		_irisColor = color;
	}

	public Color getIrisColor() {
		return _irisColor;
	}

	public void setX(double x) {
		_x = x;
	}

	public void setY(double y) {
		_y = y;
	}

	public Group shapes() {
		_radius = 2.0;

		double a;
		if (_x < 0) {
			a = -0.75;
		} else {
			a = 0.75;
		}

		Circle eye = new Circle();
		eye.setRadius(_radius);
		Group dGroup = new Group();

		eye.setFill(Color.BLACK);
		eye.setCenterX(_x + a);
		eye.setCenterY(_y + 1.5);
		dGroup.getChildren().add(eye);

		Circle eyeI = new Circle();
		eyeI.setFill(Color.WHITE);
		eyeI.setRadius(_radius - 0.25);
		eyeI.setCenterX(_x + a);
		eyeI.setCenterY(_y + 1.5);
		dGroup.getChildren().add(eyeI);

		Circle eyeIris = new Circle();
		eyeIris.setFill(_irisColor);
		eyeIris.setRadius(_radius - 1.25);
		eyeIris.setCenterX(_x);
		eyeIris.setCenterY(_y + 1.75);
		dGroup.getChildren().add(eyeIris);

		Circle eyeCenter = new Circle();
		eyeCenter.setFill(Color.BLACK);
		eyeCenter.setRadius(_radius - 1.50);
		eyeCenter.setCenterX(_x);
		eyeCenter.setCenterY(_y + 1.75);
		dGroup.getChildren().add(eyeCenter);

		return dGroup;
	}

}
