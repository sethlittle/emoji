package comp110;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;

public class Mouth {

	private double _x;
	private double _y;

	public Mouth() {
	}

	public Group shapes() {
		_x = 0;
		_y = 0;
		Group bGroup = new Group();

		Circle mouth = new Circle();
		mouth.setFill(Color.BLACK);
		mouth.setRadius(2.0);
		mouth.setCenterX(_x);
		mouth.setCenterY(_y + 4.5 + 1.5);

		bGroup.getChildren().add(mouth);

		return bGroup;
	}

	public Group tongue() {
		Group group = new Group();
		_x = 0;
		_y = 0;

		Rectangle tongue = new Rectangle();
		tongue.setFill(Color.PALEVIOLETRED);
		tongue.setX(_x - 1.5);
		tongue.setY(_y + 4.5 + 2.25);
		tongue.setWidth(3.0);
		tongue.setHeight(1.0);
		tongue.setArcHeight(7.5);
		tongue.setArcWidth(2.5);

		Rectangle tongue1 = new Rectangle();
		tongue1.setFill(Color.PALEVIOLETRED);
		tongue1.setX(_x - 1.2);
		tongue1.setY(_y + 4.5 + 2.50);
		tongue1.setWidth(2.4);
		tongue1.setHeight(1.0);
		tongue1.setArcHeight(7.5);
		tongue1.setArcWidth(5.0);

		group.getChildren().add(tongue);
		group.getChildren().add(tongue1);
		return group;

	}

	public Group facialHair() {
		Group g = new Group();
		_x = 0;
		_y = 0;
		Rectangle m;

		for (int i = 1; i < 10; i++) {
			m = new Rectangle();
			m.setFill(Color.BLACK);
			m.setWidth(2.00);
			m.setHeight(0.70);
			m.setX(_x - m.getWidth() - (0.15 * i));
			m.setY(_y + 3.25 + (0.15 * i));
			m.setArcHeight(5.0);
			m.setArcWidth(2.5);
			m.setRotate(-i * 7.75);
			g.getChildren().add(m);
		}

		for (int i = 1; i < 10; i++) {
			m = new Rectangle();
			m.setFill(Color.BLACK);
			m.setWidth(2.00);
			m.setHeight(0.70);
			m.setX(_x + (0.15 * i));
			m.setY(_y + 3.25 + (0.15 * i));
			m.setArcHeight(5.0);
			m.setArcWidth(2.5);
			m.setRotate(i * 7.75);
			g.getChildren().add(m);
		}

		for (int i = 0; i < 15; i++) {
			m = new Rectangle();
			m.setFill(Color.BLACK);
			m.setWidth(1);
			m.setHeight(1.25);
			m.setX(_x - m.getWidth() + 0.4);
			m.setY(_y + 8);
			m.setArcHeight(1.5 + (0.7 * i));
			m.setArcWidth(4.0 + (0.2 * i));
			m.setRotate(-i * 5.0);
			g.getChildren().add(m);

			m = new Rectangle();
			m.setFill(Color.BLACK);
			m.setWidth(1);
			m.setHeight(1.25);
			m.setX(_x - 0.4);
			m.setY(_y + 8);
			m.setArcHeight(1.5 + (0.7 * i));
			m.setArcWidth(4.0 + (0.2 * i));
			m.setRotate(i * 5.0);
			g.getChildren().add(m);
		}

		for (int i = 2; i < 12; i++) {
			m = new Rectangle();
			m.setFill(Color.BLACK);
			m.setWidth(1.7);
			m.setHeight(0.5 + (i * 0.1));
			m.setX(_x - m.getWidth() - 5.0 + (0.5 * i));
			m.setY(_y + 8.5 + (i * 0.1));
			m.setArcHeight(2);
			m.setArcWidth(4.0);
			m.setRotate(-i * 0.20);
			g.getChildren().add(m);

			m = new Rectangle();
			m.setFill(Color.BLACK);
			m.setWidth(1.7);
			m.setHeight(0.5 + (i * 0.1));
			m.setX(_x + 5.0 - (0.5 * i));
			m.setY(_y + 8.5 + (i * 0.1));
			m.setArcHeight(2);
			m.setArcWidth(4.0);
			m.setRotate(i * 0.20);
			g.getChildren().add(m);
		}

		return g;
	}

}
