package comp110;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Path;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.Rectangle;

public class Nose {

	private double _x;
	private double _y;

	public Nose() {

	}

	public Group shapes() {
		_x = 0;
		_y = 0;
		Group cGroup = new Group();

		Path left = new Path();
		left.setStroke(Color.BLACK);
		left.setStrokeWidth(0.2);

		MoveTo move = new MoveTo();
		move.setX(_x - 1.0);
		move.setY(_y + 2);
		LineTo to = new LineTo();
		to.setX(_x);
		to.setY(_y + 0.05);
		left.getElements().add(move);
		left.getElements().add(to);
		cGroup.getChildren().add(left);

		Path right = new Path();
		right.setStroke(Color.BLACK);
		right.setFill(Color.BLACK);
		right.setStrokeWidth(0.2);

		MoveTo move1 = new MoveTo();
		move1.setX(_x);
		move1.setY(_y + 0.05);
		LineTo to1 = new LineTo();
		to1.setX(_x + 1.0);
		to1.setY(_y + 2);
		right.getElements().add(move1);
		right.getElements().add(to1);
		cGroup.getChildren().add(right);

		Path bottom = new Path();
		bottom.setStroke(Color.BLACK);
		bottom.setStrokeWidth(0.2);

		MoveTo move2 = new MoveTo();
		move2.setX(_x - 1.0);
		move2.setY(_y + 2);
		LineTo to2 = new LineTo();
		to2.setX(_x + 1.0);
		to2.setY(_y + 2);
		bottom.getElements().add(move2);
		bottom.getElements().add(to2);
		cGroup.getChildren().add(bottom);

		Rectangle nostrilL = new Rectangle();
		nostrilL.setFill(Color.BLACK);
		nostrilL.setWidth(0.75);
		nostrilL.setHeight(0.3);
		nostrilL.setX(_x - nostrilL.getWidth() - 0.15);
		nostrilL.setY(_y + 1.75);
		nostrilL.setArcHeight(7.5);
		nostrilL.setArcWidth(5.0);
		cGroup.getChildren().add(nostrilL);

		Rectangle nostrilR = new Rectangle();
		nostrilR.setFill(Color.BLACK);
		nostrilR.setWidth(0.75);
		nostrilR.setHeight(0.3);
		nostrilR.setX(_x + 0.15);
		nostrilR.setY(_y + 1.75);
		nostrilR.setArcHeight(7.5);
		nostrilR.setArcWidth(5.0);
		cGroup.getChildren().add(nostrilR);

		cGroup.setScaleX(1.2);
		cGroup.setScaleY(1.2);
		cGroup.setScaleZ(1.2);

		return cGroup;
	}

}
