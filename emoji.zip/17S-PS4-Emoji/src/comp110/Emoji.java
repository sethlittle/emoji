package comp110;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Path;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Circle;

public class Emoji {

	private FaceShape _faceShape;
	private Mouth _mouth;
	private Nose _nose;
	private Eye _leftEye;
	private Eye _rightEye;
	private double _x;
	private double _y;
	private EyeBrow _eyeBrow;
	private Hat _hat;
	private Rectangle _rectangle;
	private Circle _circle;
	private Path _path;

	public Emoji() {
		_hat = new Hat();
		this.setFaceShape(new FaceShape(Color.BURLYWOOD));
		this.getFaceShape();
		_mouth = new Mouth();
		_nose = new Nose();
		this.setLeftEye(new Eye(Color.SADDLEBROWN));
		this.getLeftEye();
		this.setRightEye(new Eye(Color.SADDLEBROWN));
		this.getRightEye();
		_eyeBrow = new EyeBrow();
		_rectangle = new Rectangle();
		_circle = new Circle();
		_path = new Path();
	}

	public FaceShape getFaceShape() {
		return _faceShape;
	}

	public void setFaceShape(FaceShape faceShape) {
		_faceShape = faceShape;
	}

	public Eye getLeftEye() {
		return _leftEye;
	}

	public void setLeftEye(Eye eye) {
		_leftEye = eye;
	}

	public Eye getRightEye() {
		return _rightEye;
	}

	public void setRightEye(Eye eye) {
		eye.setX(3.0);
		_rightEye = eye;
	}

	public Group shapes() {
		_x = 0;
		_y = 0;
		Group group = new Group();

		group.getChildren().add(_hat.shapes());
		group.getChildren().add(_faceShape.shapes());
		group.getChildren().add(_nose.shapes());
		group.getChildren().add(_leftEye.shapes());
		group.getChildren().add(_rightEye.shapes());
		group.getChildren().add(_eyeBrow.shapes());
		group.getChildren().add(_mouth.shapes());
		group.getChildren().add(_hat.getBill());
		group.getChildren().add(_hat.three());
		group.getChildren().add(_hat.fill());
		group.getChildren().add(_mouth.tongue());
		group.getChildren().add(_mouth.facialHair());

		group.setTranslateX(_x);
		group.setTranslateY(_y);

		return group;
	}
}
