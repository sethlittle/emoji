package comp110;

import javafx.scene.Group;
import javafx.scene.paint.Color;

import javafx.scene.shape.Rectangle;

public class EyeBrow {

	private double _x;
	private double _y;
	private double _angle;

	public EyeBrow() {
		_angle = 0.3;
	}

	public Group shapes() {
		Group group = new Group();
		Rectangle eyebrow;
		Rectangle eyebrow1;
		_x = 0;
		_y = 0;

		for (double i = 0.0; i < 1.2; i = i + _angle) {
			eyebrow = new Rectangle();
			eyebrow.setFill(Color.BLACK);
			eyebrow.setWidth(2.0);
			eyebrow.setHeight(0.5);
			eyebrow.setArcWidth(0.5);
			eyebrow.setArcHeight(0.5);
			eyebrow.setX(_x - 6.75 + (i + 0.5) * 2.0);
			eyebrow.setY(_y - 4.25);
			eyebrow.setRotate((i - 0.5) * 50.0);
			group.getChildren().add(eyebrow);

			eyebrow1 = new Rectangle();
			eyebrow1.setFill(Color.BLACK);
			eyebrow1.setWidth(2.0);
			eyebrow1.setHeight(0.5);
			eyebrow1.setArcWidth(0.5);
			eyebrow1.setArcHeight(0.5);
			eyebrow1.setX(_x + 6.75 - (eyebrow1.getWidth() + (i + 0.5) * 2.0));
			eyebrow1.setY(_y - 4.25);
			eyebrow1.setRotate((-i + 0.5) * 50.0);
			group.getChildren().add(eyebrow1);
		}

		return group;
	}

}
