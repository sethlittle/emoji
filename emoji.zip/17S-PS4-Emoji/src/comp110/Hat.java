package comp110;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Path;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.LineTo;

public class Hat {

	private double _x;
	private double _y;

	public Hat() {
		// Chance the Rapper Hat
	}

	public Group shapes() {
		_x = 0;
		_y = 0;
		Group group = new Group();

		Circle top = new Circle();
		top.setFill(Color.BLACK);
		top.setCenterX(_x);
		top.setCenterY(_y - 7.0);
		top.setRadius(8.5);

		group.getChildren().add(top);
		return group;
	}

	public Group getBill() {
		_x = 0;
		_y = 0;

		Group group1 = new Group();

		Rectangle bill1 = new Rectangle();
		bill1.setX(_x - 8.0);
		bill1.setY(_y - 10.0);
		bill1.setWidth(14.0);
		bill1.setHeight(3.0);
		bill1.setArcHeight(10.0);
		bill1.setArcWidth(10.0);
		group1.getChildren().add(bill1);

		Rectangle bill = new Rectangle();
		bill.setX(_x - 8.50);
		bill.setY(_y - 8.50);
		bill.setWidth(23.0);
		bill.setHeight(4.0);
		bill.setArcHeight(10.0);
		bill.setArcWidth(20.0);
		group1.getChildren().add(bill);

		Path line = new Path();
		line.setStroke(Color.GREY);
		line.setStrokeWidth(0.2);

		MoveTo move = new MoveTo();
		move.setX(_x + 8.1);
		move.setY(_y - 8.7);
		LineTo to = new LineTo();
		to.setX(_x + 7.0);
		to.setY(_y - 8.0);
		line.getElements().add(move);
		line.getElements().add(to);
		group1.getChildren().add(line);

		Path lineM = new Path();
		lineM.setStroke(Color.GREY);
		lineM.setStrokeWidth(0.2);

		MoveTo moveM = new MoveTo();
		moveM.setX(_x + 7.0);
		moveM.setY(_y - 8.0);
		LineTo toM = new LineTo();
		toM.setX(_x - 0.5);
		toM.setY(_y - 6.65);
		lineM.getElements().add(moveM);
		lineM.getElements().add(toM);
		group1.getChildren().add(lineM);

		Path line1 = new Path();
		line1.setStroke(Color.GREY);
		line1.setStrokeWidth(0.2);

		MoveTo move1 = new MoveTo();
		move1.setX(_x - 0.5);
		move1.setY(_y - 6.65);
		LineTo to1 = new LineTo();
		to1.setX(_x - 8.0);
		to1.setY(_y - 6.40);
		line1.getElements().add(move1);
		line1.getElements().add(to1);
		group1.getChildren().add(line1);

		return group1;
	}

	public Group three() {
		_x = 0;
		_y = 0;

		Group group1 = new Group();

		Rectangle top = new Rectangle();
		top.setFill(Color.WHITE);
		top.setX(_x - 0.95);
		top.setY(_y - 13.5);
		top.setWidth(3.0);
		top.setHeight(0.75);
		group1.getChildren().add(top);

		Path middle = new Path();
		middle.setStroke(Color.WHITE);
		middle.setStrokeWidth(0.75);

		MoveTo move = new MoveTo();
		move.setX(_x + 2.5);
		move.setY(_y - 13.5);
		LineTo to = new LineTo();
		to.setX(_x + 1.5);
		to.setY(_y - 12.0);
		middle.getElements().add(move);
		middle.getElements().add(to);
		group1.getChildren().add(middle);

		Circle bottomOutside = new Circle();
		bottomOutside.setRadius(2.25);
		bottomOutside.setFill(Color.WHITE);
		bottomOutside.setCenterX(_x + 0.5);
		bottomOutside.setCenterY(_y - 10.0);
		group1.getChildren().add(bottomOutside);

		return group1;
	}

	public Group fill() {
		_x = 0;
		_y = 0;
		Group g = new Group();

		Rectangle cover = new Rectangle();
		cover.setFill(Color.BLACK);
		cover.setX(_x - 1.0);
		cover.setY(_y - 14.25);
		cover.setWidth(5.0);
		cover.setHeight(0.75);
		g.getChildren().add(cover);

		Circle bottomInside = new Circle();
		bottomInside.setRadius(1.5);
		bottomInside.setFill(Color.BLACK);
		bottomInside.setCenterX(_x + 0.5);
		bottomInside.setCenterY(_y - 10.0);
		g.getChildren().add(bottomInside);

		Path middleCover = new Path();
		middleCover.setStroke(Color.BLACK);
		middleCover.setStrokeWidth(0.75);

		MoveTo move = new MoveTo();
		move.setX(_x + 0.63);
		move.setY(_y - 12.08);
		LineTo to = new LineTo();
		to.setX(_x - 1.75);
		to.setY(_y - 9.0);
		middleCover.getElements().add(move);
		middleCover.getElements().add(to);
		g.getChildren().add(middleCover);

		Path middleCover1 = new Path();
		middleCover1.setStroke(Color.BLACK);
		middleCover1.setStrokeWidth(0.95);

		MoveTo move1 = new MoveTo();
		move1.setX(_x - 0.30);
		move1.setY(_y - 12.10);
		LineTo to1 = new LineTo();
		to1.setX(_x - 2.75);
		to1.setY(_y - 9.0);
		middleCover1.getElements().add(move1);
		middleCover1.getElements().add(to1);
		g.getChildren().add(middleCover1);

		return g;
	}

}
